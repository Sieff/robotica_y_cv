#! /bin/bash
export TURTLEBOT3_MODEL=burger
roslaunch robotics_challenge robotics_challenge.launch
